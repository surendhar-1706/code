'use client';

const ExploreCard = () => (
  <div>
    Explore Card
  </div>
);

export default ExploreCard;

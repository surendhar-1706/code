'use client';

export const TypingText = () => (
  <p>Typing Text</p>
);

export const TitleText = () => (
  <h2>Title Text</h2>
);
